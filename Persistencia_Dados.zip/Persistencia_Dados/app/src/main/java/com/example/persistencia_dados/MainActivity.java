package com.example.persistencia_dados;
/*Rolan Tembe
passar dados de uma actividade para outra usado sharedPrefere,
QUArta-feira= apresentacao do aplicativo*/

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
 private Button bt_gravar;
 private EditText idade,nome;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*  Metodo requestFocus();
        * Isso fará com que o teclado seja exibido automaticamente
        * assim que a activity for iniciada,
        * permitindo que o usuário insira texto imediatamente.*/


        idade=findViewById(R.id.idEd_idade);
        nome=findViewById(R.id.idEd_seuNome);
        bt_gravar=findViewById(R.id.idButton);

        String  usernameIdade= idade.getText().toString();
        String usernameNome=nome.getText().toString();

        idade.requestFocus();
        bt_gravar.setOnClickListener(view ->{
            SharedPreferences sharedPreferences=getSharedPreferences("chaveGeral", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("chaveIdadde",usernameIdade);
            editor.putString("chaveNome",usernameNome);
            editor.commit();

            Intent intent = new Intent(MainActivity.this,MainActivity2.class);
            startActivity(intent);

        });

    }


}