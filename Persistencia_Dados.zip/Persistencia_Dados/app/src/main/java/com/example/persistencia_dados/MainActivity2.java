package com.example.persistencia_dados;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity2 extends AppCompatActivity {

    private TextView txt1,txt2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        txt1=findViewById(R.id.idTV_visualizarIdade);
        txt2=findViewById(R.id.idTV_visualizarNome);

        SharedPreferences sharedPreferences = getSharedPreferences("chaveGeral",MODE_PRIVATE);

       String usernameIdade= sharedPreferences.getString("chaveIdade","");
       String usernameNome=sharedPreferences.getString("chaveNome","");

       txt1.setText("idade ," +usernameIdade);
       txt2.setText("Nome ," +usernameNome);







    }
}